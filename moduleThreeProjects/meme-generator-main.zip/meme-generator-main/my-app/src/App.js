import React from "react"
// import Banner from "./Banner"
import MemeGenerator from "./MemeGenerator"
import "./style.css"


function App(){
    return (
        <div>
            {/* <Banner /> */}
            <MemeGenerator />
        </div>
    )
}
export default App