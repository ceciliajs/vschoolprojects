# Welcome to Meme Generator Project

<b>Authors:</b>
Cecilia Stark
Anthony Maisonet